### Hexlet tests and linter status:
[![Actions Status](https://github.com/webdron/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/webdron/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/da17a1a62b8038c5be1d/maintainability)](https://codeclimate.com/github/webdron/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/TTJuomILLbsx81SZ891fiAYe2.svg)](https://asciinema.org/a/TTJuomILLbsx81SZ891fiAYe2)
[![asciicast](https://asciinema.org/a/IzQ9hnu5mf6UlXCKMY8pnsPKW.svg)](https://asciinema.org/a/IzQ9hnu5mf6UlXCKMY8pnsPKW)