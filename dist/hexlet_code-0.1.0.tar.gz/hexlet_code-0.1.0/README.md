### Hexlet tests and linter status:
[![Actions Status](https://github.com/webdron/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/webdron/python-project-49/actions)